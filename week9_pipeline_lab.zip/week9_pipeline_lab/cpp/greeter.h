// Week 9 lab starter — Build Your First Pipeline — SDEV 3320
#pragma once
#include <string>

inline std::string greet(const std::string& name) {
    if (name.empty()) {
        return "Hello, stranger!";
    }
    return "Hello, " + name + "!";
}
