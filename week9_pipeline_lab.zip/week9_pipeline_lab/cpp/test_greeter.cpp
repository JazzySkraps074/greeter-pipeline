// Week 9 lab starter — Build Your First Pipeline — SDEV 3320
#include <gtest/gtest.h>
#include "greeter.h"

TEST(GreeterTest, GreetWithName) {
    EXPECT_EQ(greet("Ada"), "Hello, Ada!");
}

TEST(GreeterTest, GreetWithEmptyString) {
    EXPECT_EQ(greet(""), "Hello, stranger!");
}
